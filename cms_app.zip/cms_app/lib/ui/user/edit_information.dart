import 'package:cms_app/ui/user/user.dart';
import 'package:flutter/material.dart';

class UserInfor extends StatelessWidget {
  const UserInfor({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sửa thông tin'),
        backgroundColor: Colors.blue,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
                      Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const UserPage()),
            );
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Avatar section
              Center(
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.grey[300],
                      child: const Icon(Icons.person, size: 50),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: IconButton(
                        icon: const Icon(Icons.camera_alt),
                        onPressed: () {

                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Name field
              const TextField(
                //controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Họ tên',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),

              // Phone number field
              const TextField(
                //controller: _phoneController,
                decoration: InputDecoration(
                  labelText: 'Số điện thoại',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 20),

              // Date of birth field
               Row(
                children: [
                  const Expanded(
                    child: InputDecorator(
                      decoration: InputDecoration(
                        labelText: 'Ngày sinh',
                        border: OutlineInputBorder(),

                      ),

                    ),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    icon: const Icon(Icons.calendar_today),
                    onPressed: () {

                    },
                  ),

                ],
              ),
              const SizedBox(height: 20),


              const TextField(
                decoration: InputDecoration(
                  labelText: 'Phòng ban',
                  hintText: 'Video - podcast',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),


              const Text('Bút danh', style: TextStyle(fontSize: 16)),
              Row(
                children: [
                  const Expanded(
                    child: TextField(

                      decoration: InputDecoration(
                        hintText: 'Thêm bút danh',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () {
                    },
                  ),
                ],
              ),
              const SizedBox(height: 10),


              Wrap(
                children: [
                  Chip(
                    label: const Text('PHAN HẢI ĐĂNG'),
                    onDeleted: () {

                    },
                  ),
                  const SizedBox(width: 10),
                  Chip(
                    label: const Text('HẢI ĐĂNG'),
                    onDeleted: () {}

                  ),
                ],
              ),

              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      onPressed: () {},
                      child: const Text('Cập Nhật'),
                    ),
                    ElevatedButton(
                      onPressed: () {},
                      child: const Text('Hủy'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
