import 'package:cms_app/ui/login/login.dart';
import 'package:flutter/material.dart';
import '../home/home.dart';
import 'edit_information.dart';

class UserPage extends StatelessWidget {
  const UserPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tài khoản'),
        backgroundColor: Colors.blue,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            // Sử dụng Navigator.pushReplacement để quay lại trang Home
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomePage()),
            );
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Avatar và icon camera
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Avatar và icon camera
                  Stack(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.grey[300],
                        radius: 40,
                        child: const Icon(Icons.person, size: 56),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: IconButton(
                          icon: const Icon(Icons.camera_alt),
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 16),
                  // Tên người dùng
                  const Text(
                    'Kylian Mbappe',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            // TextField cho phân quyền
            ListTile(
              title: const Text('Phân quyền'),
              trailing: const Text("Phóng Viên",),
              onTap: () {},
            ),
            const SizedBox(height: 16),

            // TextField cho chỉnh sửa thông tin
            ListTile(
              title: const Text('Chỉnh sửa thông tin'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const UserInfor()),
                );
              },
            ),
            const SizedBox(height: 16),

            // TextField cho cài đặt Face ID
            ListTile(
              title: const Text('Cài đặt Face ID'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {},
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.login),
              title: const Text('Đăng xuất'),
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginPage()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
