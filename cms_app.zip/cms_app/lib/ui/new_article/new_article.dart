import 'package:flutter/material.dart';

import '../home/home.dart';

class NewArticlePage extends StatelessWidget {
  const NewArticlePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Viết bài mới'),
          backgroundColor: Colors.blue,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const HomePage()),
              );
            },
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              // Tab cho nội dung và thông tin bài viết
              DefaultTabController(
                length: 2,
                child: Column(
                  children: [
                    const TabBar(
                      tabs: [
                        Tab(text: 'Nội dung'),
                        Tab(text: 'Thông tin bài viết'),
                      ],
                    ),
                    SizedBox(
                      height: 590, // Chiều cao của vùng nội dung
                      child: TabBarView(
                        children: [
                          // Nội dung
                          Container(
                            padding: const EdgeInsets.all(16.0),
                            child: const Column(
                              children: [
                                TextField(
                                  decoration: InputDecoration(
                                    labelText: 'Tiêu đề bài viết',
                                    border: UnderlineInputBorder(),
                                  ),
                                ),
                                SizedBox(height: 16),
                                TextField(
                                  decoration: InputDecoration(
                                    labelText: 'Mô tả bài viết',
                                    border: UnderlineInputBorder(),
                                  ),
                                ),
                                SizedBox(height: 28),
                                TextField(
                                  maxLines: 16,
                                  decoration: InputDecoration(
                                    border: UnderlineInputBorder(),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          // Thông tin bài viết
                          // Center(
                          //   child: Text('Thông tin bài viết sẽ hiển thị ở đây.'),
                          // ),

                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Column(
                              children: [
                                TextField(
                                  decoration: InputDecoration(
                                    labelText: 'Tiêu đề bài viết',
                                    prefixIcon: Padding(
                                      padding: const EdgeInsets.only(
                                          right:
                                              8.0, bottom: 16), // Khoảng cách giữa icon và text
                                      child: Image.asset(
                                        'assets/images/logo1.png',
                                        width: 48,
                                        height: 48,
                                      ),
                                    ),
                                    border: const UnderlineInputBorder(),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                const TextField(
                                  decoration: InputDecoration(
                                    labelText: 'Mô tả bài viết',
                                    border: UnderlineInputBorder(),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                // Trường tác giả
                                ListTile(
                                  title: const Text('Tác giả'),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap: () {},
                                ),
                                const SizedBox(height: 16),
                                // Trường chuyên mục
                                ListTile(
                                  title: const Text('Chuyên mục'),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap: () {},
                                ),
                                const SizedBox(height: 16),
                                // Trường loại nội dung
                                // Row(
                                //   children: [
                                //     const Expanded(
                                //       flex: 2,
                                //       child: TextField(
                                //         decoration: InputDecoration(
                                //           labelText: 'Loại nội dung',
                                //           enabledBorder: UnderlineInputBorder(
                                //             borderSide:
                                //                 BorderSide(color: Colors.black),
                                //           ),
                                //           focusedBorder: UnderlineInputBorder(
                                //             borderSide:
                                //                 BorderSide(color: Colors.blue),
                                //           ),
                                //         ),
                                //         enabled:
                                //             false, // Không cho phép gõ vào TextField
                                //       ),
                                //     ),
                                //     Expanded(
                                //       flex: 1,
                                //       child: DropdownButton<String>(
                                //         isExpanded: true,
                                //         value: 'Chọn',
                                //         items: <String>[
                                //           'Chọn',
                                //           'Tin 1',
                                //           'Tin 2',
                                //           'Tin 3'
                                //         ].map<DropdownMenuItem<String>>(
                                //             (String value) {
                                //           return DropdownMenuItem<String>(
                                //             value: value,
                                //             child: Text(value),
                                //           );
                                //         }).toList(),
                                //         onChanged: (String? newValue) {
                                //           // Hành động khi chọn một mục trong dropdown
                                //           print('Đã chọn: $newValue');
                                //         },
                                //       ),
                                //     ),
                                //   ],
                                // ),
                                ListTile(
                                  title: const Text('Loại nội dung'),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap: () {},
                                ),
                                const SizedBox(height: 16),
                                // Trường tin liên quan
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    const Expanded(
                                      flex: 6,
                                      child: TextField(
                                        decoration: InputDecoration(
                                          labelText: 'Tin liên quan',
                                          border: UnderlineInputBorder(),
                                        ),
                                      ),
                                      // child: Text(
                                      //   'Tin liên quan', // Nhãn hiển thị
                                      //   style: TextStyle(fontSize: 16),
                                      // ),
                                    ),
                                    Expanded(
                                      child: Row(
                                        children: [
                                          const Expanded(
                                            child: TextField(
                                              decoration: InputDecoration(
                                                hintText: 'Tin liên quan',
                                                border: UnderlineInputBorder(),
                                              ),
                                            ),
                                          ),
                                          IconButton(
                                            icon: const Icon(Icons.add),
                                            onPressed: () {
                                            },
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                                const SizedBox(height: 16),
                                // Trường tag
                                const TextField(
                                  decoration: InputDecoration(
                                    labelText: 'Tag',
                                    border: UnderlineInputBorder(),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              //const SizedBox(height: 4),
              // Nút điều hướng
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      // Hành động gửi bài viết
                      print('Gửi bài viết');
                    },
                    child: const Text('Gửi'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Hành động chuyển bài viết
                      print('Chuyển bài viết');
                    },
                    child: const Text('Chuyển'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Hành động lưu bài viết
                      print('Lưu bài viết');
                    },
                    child: const Text('Lưu'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Hành động đóng
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const HomePage()),
                      );
                    },
                    child: const Text('Đóng'),
                  ),
                ],
              ),
            ],
          ),
        ));
  }
}
