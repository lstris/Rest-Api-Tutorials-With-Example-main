
import 'package:cms_app/ui/user/user.dart';
import 'package:flutter/material.dart';

import '../new_article/new_article.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
            color: Colors.blueGrey,
            icon: const Icon(Icons.account_circle),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const UserPage()),
              );
            },
          ),

          // leading: IconButton(
          //   icon: Icon(Icons.arrow_back),
          //   onPressed: () {
          //     Navigator.pushReplacement(
          //       context,
          //       MaterialPageRoute(builder: (context) => const HomePage()),
          //     );
          //   },
          // ),
        ],
      ),

      // Drawer cho các mục chính
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Container(
              height: 150,
              color: Colors.blue,
              child: const DrawerHeader(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                      size: 48,
                    ),
                    SizedBox(height: 9),
                    Text(
                      'Phóng viên',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Các mục trong drawer
            ListTile(
              leading: const Icon(Icons.dashboard_outlined),
              title: const Text('Dashboard'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.document_scanner),
              title: const Text('Bài đang viết'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.document_scanner_outlined),
              title: const Text('Bài chờ biên tập'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              subtitle: const Text('hihi'),
              leading: const Icon(Icons.send_and_archive),
              title: const Text('Bài đã xuất bản'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.archive_outlined),
              title: const Text('Bài trả lại'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),

      // Nội dung chính của trang
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                labelText: 'Tìm kiếm',
                prefixIcon: const Icon(Icons.search, color: Colors.blue),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(color: Colors.grey),
                ),
                contentPadding: const EdgeInsets.all(12.0),
              ),
            ),
          ),
          Container(
            color: const Color(0xF7F7F7F7),
            // Màu nền
            padding: const EdgeInsets.all(12.0),
            width: double.infinity,
            // Chiều rộng tự động lấp đầy không gian có sẵn
            child: const Text(
              'Bài đang viết',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold, // Để làm văn bản đậm
              ),
            ),
          ),
          const Expanded(
            child: Center(
              child: Text('Nội dung sẽ hiển thị ở đây.'),
            ),
          )
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const NewArticlePage()),
          );
        },
        icon: const Icon(Icons.pending), // Icon của nút
        label: const Text('Viết bài mới'), // Văn bản đi kèm
        backgroundColor: const Color(0xFFF7F7F7), // Màu nền của nút
      ),
    );
  }
}
