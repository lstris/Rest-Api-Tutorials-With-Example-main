import 'package:cms_app/ui/login/login.dart';
import 'package:flutter/cupertino.dart';

void main()=> runApp(const CMSApp() as Widget);